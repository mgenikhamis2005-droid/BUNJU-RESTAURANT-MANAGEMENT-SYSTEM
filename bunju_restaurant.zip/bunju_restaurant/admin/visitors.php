<?php require '_top.php';
$n=fn($s)=>(int)$pdo->query($s)->fetchColumn();
$top=$pdo->query("SELECT page,COUNT(*) v FROM website_visitors GROUP BY page ORDER BY v DESC")->fetchAll();
$days=$pdo->query("SELECT DATE(visited_at) d,COUNT(*) v,COUNT(DISTINCT session_id) u FROM website_visitors GROUP BY d ORDER BY d DESC LIMIT 14")->fetchAll();
$rec=$pdo->query("SELECT * FROM website_visitors ORDER BY id DESC LIMIT 50")->fetchAll(); ?>
<h1>Website Visitors</h1>
<div class="stats"><div class="stat"><b><?= $n("SELECT COUNT(DISTINCT session_id) FROM website_visitors") ?></b>Total visitors (unique sessions)</div><div class="stat"><b><?= $n("SELECT COUNT(*) FROM website_visitors") ?></b>Total page visits</div><div class="stat"><b><?= $n("SELECT COUNT(DISTINCT session_id) FROM website_visitors WHERE DATE(visited_at)=CURDATE()") ?></b>Visitors today</div></div>
<div class="panel"><h2>Most Visited Pages</h2><div class="tw"><table><tr><th>Page</th><th>Visits</th></tr><?php foreach($top as $t): ?><tr><td><?= e(ucfirst($t['page'])) ?></td><td><?= $t['v'] ?></td></tr><?php endforeach; ?></table></div></div>
<div class="panel"><h2>Daily Summary (last 14 days)</h2><div class="tw"><table><tr><th>Date</th><th>Visitors</th><th>Page visits</th></tr><?php foreach($days as $d): ?><tr><td><?= e($d['d']) ?></td><td><?= $d['u'] ?></td><td><?= $d['v'] ?></td></tr><?php endforeach; ?></table></div></div>
<div class="panel"><h2>Recent Visits</h2><div class="tw"><table><tr><th>Date and time</th><th>Page</th><th>Session</th></tr><?php foreach($rec as $r): ?><tr><td><?= e($r['visited_at']) ?></td><td><?= e(ucfirst($r['page'])) ?></td><td class="small"><?= e(substr($r['session_id'],0,8)) ?>...</td></tr><?php endforeach; ?></table></div></div>
<?php require '_bottom.php'; ?>
