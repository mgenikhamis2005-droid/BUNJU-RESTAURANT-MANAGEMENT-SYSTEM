<?php require_once __DIR__.'/../config/config.php'; require_admin(); $B=BASE_URL; $cur=basename($_SERVER['PHP_SELF']);
function logact($m){ global $pdo; $pdo->prepare("INSERT INTO activity_log(message) VALUES(?)")->execute([$m]); }
$links=['index.php'=>'Dashboard','foods.php'=>'Food Management','categories.php'=>'Categories','gallery.php'=>'Gallery','slider.php'=>'Slider Images','messages.php'=>'Messages','visitors.php'=>'Visitors','account.php'=>'My Account']; ?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin | BUNJU</title>
<link rel="stylesheet" href="<?= $B ?>/assets/css/style.css"></head><body><div class="adm"><aside class="side"><h2>&#127869; BUNJU Admin</h2>
<?php foreach($links as $f=>$l): ?><a href="<?= $f ?>" class="<?= $cur===$f?'on':'' ?>"><?= $l ?></a><?php endforeach; ?>
<a href="<?= $B ?>/index.php" target="_blank">View Website</a><a href="logout.php">Logout</a></aside><main class="main"><?= flash() ?>
