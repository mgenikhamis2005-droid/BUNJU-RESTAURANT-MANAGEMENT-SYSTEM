<?php
// Anonymous visitor tracking: random session id + page name + time. No IP or personal data stored.
if (empty($_SESSION['vid'])) $_SESSION['vid'] = bin2hex(random_bytes(16));
try { $pdo->prepare("INSERT INTO website_visitors(session_id,page) VALUES(?,?)")->execute([$_SESSION['vid'], $page]); } catch (Exception $ex) {}
