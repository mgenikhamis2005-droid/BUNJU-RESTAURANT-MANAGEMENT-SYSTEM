<?php require '_top.php'; $gc=['Food','Drinks','Interior','Exterior','Special Meals'];
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $a=$_POST['action']??''; $id=(int)($_POST['id']??0);
  if($a==='delete'){ $o=$pdo->prepare("SELECT image FROM gallery WHERE id=?"); $o->execute([$id]); $old=$o->fetchColumn(); $pdo->prepare("DELETE FROM gallery WHERE id=?")->execute([$id]); delete_file('gallery',$old); logact('Deleted a gallery image'); flash('Image deleted.'); }
  elseif($a==='save'){ $t=trim($_POST['title']??''); $c=in_array($_POST['category']??'',$gc,true)?$_POST['category']:'Food';
    if($t===''){ flash('Title is required.','err'); }
    else{ $img=upload_image('image','gallery');
      if($img===false){ }
      elseif($id){ $o=$pdo->prepare("SELECT image FROM gallery WHERE id=?"); $o->execute([$id]); $old=$o->fetchColumn();
        if($img){ $pdo->prepare("UPDATE gallery SET title=?,category=?,image=? WHERE id=?")->execute([$t,$c,$img,$id]); delete_file('gallery',$old); } else $pdo->prepare("UPDATE gallery SET title=?,category=? WHERE id=?")->execute([$t,$c,$id]);
        logact("Updated gallery image: $t"); flash('Image updated.'); }
      elseif(!$img){ flash('Please choose an image.','err'); }
      else{ $pdo->prepare("INSERT INTO gallery(title,category,image) VALUES(?,?,?)")->execute([$t,$c,$img]); logact("Uploaded gallery image: $t"); flash('Image uploaded.'); } } }
  header('Location: gallery.php'); exit; }
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM gallery WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch(); }
$imgs=$pdo->query("SELECT * FROM gallery ORDER BY id DESC")->fetchAll(); ?>
<h1>Gallery Management</h1>
<div class="panel"><h2><?= $edit?'Edit Image':'Upload Image' ?></h2><form method="post" enctype="multipart/form-data" class="fl"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
<label>Title<input name="title" required maxlength="120" value="<?= e($edit['title']??'') ?>"></label>
<label>Category<select name="category"><?php foreach($gc as $c): ?><option <?= ($edit['category']??'')===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></label>
<label>Image<?= $edit?' (leave empty to keep current)':'' ?><input type="file" name="image" accept="image/jpeg,image/png,image/webp" <?= $edit?'':'required' ?>></label>
<div class="full"><button class="btn"><?= $edit?'Update':'Upload' ?></button> <?php if($edit): ?><a class="btn dk" href="gallery.php">Cancel</a><?php endif; ?></div></form></div>
<div class="panel"><div class="tw"><table><tr><th>Image</th><th>Title</th><th>Category</th><th>Actions</th></tr><?php foreach($imgs as $g): ?><tr><td><img src="<?= $B ?>/uploads/gallery/<?= e($g['image']) ?>" alt=""></td><td><?= e($g['title']) ?></td><td><?= e($g['category']) ?></td>
<td><a class="btn sm" href="gallery.php?edit=<?= $g['id'] ?>">Edit</a> <form method="post" class="inl" data-confirm="Delete this image?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $g['id'] ?>"><button class="btn sm red">Delete</button></form></td></tr><?php endforeach; ?></table></div></div>
<?php require '_bottom.php'; ?>
