<?php require_once __DIR__.'/../config/config.php'; $B=BASE_URL;
if(!empty($_SESSION['admin_id'])){ header('Location: index.php'); exit; }
// First run only: create the default admin if none exists (username: admin, password: Admin@123)
if(!$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn()){
  $pdo->prepare("INSERT INTO admins(username,email,password_hash) VALUES(?,?,?)")->execute(['admin',R_EMAIL,password_hash('Admin@123',PASSWORD_DEFAULT)]); }
$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check();
  $_SESSION['tries']=array_filter($_SESSION['tries']??[],fn($t)=>$t>time()-900);
  if(count($_SESSION['tries'])>=5) $err='Too many attempts. Wait 15 minutes and try again.';
  else{ $st=$pdo->prepare("SELECT * FROM admins WHERE username=?"); $st->execute([trim($_POST['username']??'')]); $a=$st->fetch();
    if($a && password_verify($_POST['password']??'',$a['password_hash'])){ session_regenerate_id(true); $_SESSION['admin_id']=$a['id']; $_SESSION['admin_name']=$a['username']; $_SESSION['tries']=[]; header('Location: index.php'); exit; }
    $_SESSION['tries'][]=time(); $err='Wrong username or password.'; } } ?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login | BUNJU</title><link rel="stylesheet" href="<?= $B ?>/assets/css/style.css"></head><body style="background:var(--g)">
<div class="loginbox"><h1>&#127869; Admin Login</h1><?= flash() ?><?php if($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="form"><?= csrf_field() ?><label>Username<input name="username" required autofocus></label><label>Password<input type="password" name="password" required></label><button class="btn" style="width:100%">Login</button></form>
<p class="center"><a href="forgot.php">Forgot password?</a> &middot; <a href="<?= $B ?>/index.php">Back to website</a></p></div></body></html>
