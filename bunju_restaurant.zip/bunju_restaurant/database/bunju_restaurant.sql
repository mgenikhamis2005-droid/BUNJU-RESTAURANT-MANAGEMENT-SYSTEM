CREATE DATABASE IF NOT EXISTS bunju_restaurant CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bunju_restaurant;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS password_resets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  used TINYINT(1) DEFAULT 0,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS food_categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS foods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(500) DEFAULT NULL,
  price DECIMAL(10,2) NOT NULL,
  old_price DECIMAL(10,2) DEFAULT NULL,
  image VARCHAR(255) DEFAULT NULL,
  is_popular TINYINT(1) DEFAULT 0,
  is_offer TINYINT(1) DEFAULT 0,
  is_available TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES food_categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS gallery (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  category VARCHAR(40) NOT NULL DEFAULT 'Food',
  image VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS slider_images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) DEFAULT NULL,
  subtitle VARCHAR(200) DEFAULT NULL,
  image VARCHAR(255) NOT NULL,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS website_visitors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  session_id VARCHAR(64) NOT NULL,
  page VARCHAR(40) NOT NULL,
  visited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (session_id), INDEX (page)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS contact_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL,
  phone VARCHAR(30) DEFAULT NULL,
  message TEXT NOT NULL,
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS activity_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  message VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO food_categories (name, description) VALUES
('Seafood','Fish, prawns, calamari and more'),
('Drinks','Fresh juices, soft drinks, water'),
('Desserts','Cakes, ice cream, fruit salads'),
('Pastries and Snacks','Cakes, maandazi, sambusa, tambi'),
('Swahili Food','Pilau, biryani, wali wa nazi'),
('Traditional Food','Ugali, nyama choma, ndizi, makande'),
('Fast Food','Pizza, burgers, chips, chicken');

INSERT INTO foods (category_id,name,description,price,old_price,is_popular,is_offer) VALUES
(1,'Grilled Fish','Whole tilapia grilled with coconut and spices',18000,NULL,1,0),
(1,'Garlic Prawns','Fresh prawns cooked in garlic butter',25000,28000,1,1),
(1,'Fried Calamari','Crispy calamari rings with tartare sauce',20000,NULL,0,0),
(2,'Fresh Passion Juice','Freshly squeezed passion fruit juice',3000,NULL,0,0),
(2,'Soda','Chilled soft drink 350ml',1500,NULL,0,0),
(2,'Mineral Water','Bottled water 500ml',1000,NULL,0,0),
(3,'Chocolate Cake','Rich chocolate cake slice',5000,NULL,1,0),
(3,'Fruit Salad','Seasonal fresh fruits',4000,5000,0,1),
(4,'Maandazi (4 pcs)','Soft coconut mandazi',2000,NULL,0,0),
(4,'Sambusa (3 pcs)','Crispy beef sambusa',3000,NULL,1,0),
(5,'Pilau ya Nyama','Spiced rice cooked with tender beef',9000,NULL,1,0),
(5,'Biryani','Fragrant biryani with chicken',12000,NULL,1,0),
(5,'Wali wa Nazi','Coconut rice served with fish or beans',7000,NULL,0,0),
(6,'Nyama Choma (1kg)','Grilled goat or beef with kachumbari',28000,NULL,1,0),
(6,'Ugali na Samaki','Ugali with fried fish and greens',10000,NULL,0,0),
(6,'Makande','Traditional maize and beans stew',5000,NULL,0,0),
(7,'Chicken and Chips','Fried chicken with crispy chips',10000,12000,1,1),
(7,'Beef Burger','Juicy burger with cheese and fries',12000,NULL,0,0);
