<?php require '_top.php';
$n=fn($s)=>(int)$pdo->query($s)->fetchColumn();
$acts=$pdo->query("SELECT * FROM activity_log ORDER BY id DESC LIMIT 10")->fetchAll(); ?>
<h1>Dashboard</h1>
<div class="stats">
<div class="stat"><b><?= $n("SELECT COUNT(DISTINCT session_id) FROM website_visitors") ?></b>Total visitors</div>
<div class="stat"><b><?= $n("SELECT COUNT(*) FROM foods") ?></b>Food items</div>
<div class="stat"><b><?= $n("SELECT COUNT(*) FROM food_categories") ?></b>Categories</div>
<div class="stat"><b><?= $n("SELECT COUNT(*) FROM gallery") ?></b>Gallery images</div>
<div class="stat"><b><?= $n("SELECT COUNT(*) FROM slider_images") ?></b>Slider images</div>
<div class="stat"><b><?= $n("SELECT COUNT(*) FROM contact_messages WHERE is_read=0") ?></b>Unread messages</div></div>
<div class="panel"><h2>Recent Activities</h2><?php if(!$acts) echo '<p>No activity yet.</p>'; ?><div class="tw"><table><?php foreach($acts as $a): ?><tr><td><?= e($a['message']) ?></td><td class="small"><?= e($a['created_at']) ?></td></tr><?php endforeach; ?></table></div></div>
<?php require '_bottom.php'; ?>
