<?php $page='gallery'; $title='Gallery'; require 'includes/header.php';
$imgs=$pdo->query("SELECT * FROM gallery ORDER BY id DESC")->fetchAll();
$cats=array_values(array_unique(array_column($imgs,'category'))); ?>
<section class="pagehead"><h1>Gallery</h1><p>A taste of BUNJU RESTAURANT</p></section>
<section class="sec wrap">
<?php if(!$imgs): ?><p class="center">No gallery images yet. The administrator can upload them from the dashboard.</p><?php else: ?>
<div class="chips" id="gfilter"><a href="#" data-c="all" class="on">All</a><?php foreach($cats as $c): ?><a href="#" data-c="<?= e($c) ?>"><?= e($c) ?></a><?php endforeach; ?></div>
<div class="ggrid"><?php foreach($imgs as $g): ?><figure data-c="<?= e($g['category']) ?>"><img src="<?= $B ?>/uploads/gallery/<?= e($g['image']) ?>" alt="<?= e($g['title']) ?>" loading="lazy"><figcaption><?= e($g['title']) ?></figcaption></figure><?php endforeach; ?></div><?php endif; ?></section>
<div class="modal" id="lightbox"><button class="mx" id="lclose">&times;</button><img id="limg" alt=""><p id="lcap"></p></div>
<?php require 'includes/footer.php'; ?>
