<?php require '_top.php'; $id=(int)$_SESSION['admin_id'];
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $a=$_POST['action']??'';
  if($a==='email'){ $m=trim($_POST['email']??''); if(filter_var($m,FILTER_VALIDATE_EMAIL)){ $pdo->prepare("UPDATE admins SET email=? WHERE id=?")->execute([$m,$id]); flash('Email updated.'); } else flash('Invalid email.','err'); }
  if($a==='password'){ $st=$pdo->prepare("SELECT password_hash FROM admins WHERE id=?"); $st->execute([$id]); $h=$st->fetchColumn(); $p1=$_POST['p1']??'';
    if(!password_verify($_POST['cur']??'',$h)) flash('Current password is wrong.','err'); elseif(strlen($p1)<8) flash('New password must be at least 8 characters.','err'); elseif($p1!==($_POST['p2']??'')) flash('Passwords do not match.','err');
    else{ $pdo->prepare("UPDATE admins SET password_hash=? WHERE id=?")->execute([password_hash($p1,PASSWORD_DEFAULT),$id]); logact('Password changed'); flash('Password changed.'); } }
  header('Location: account.php'); exit; }
$st=$pdo->prepare("SELECT * FROM admins WHERE id=?"); $st->execute([$id]); $me=$st->fetch(); ?>
<h1>My Account</h1>
<div class="panel"><h2>Email (used for password reset codes)</h2><form method="post" class="fl"><?= csrf_field() ?><input type="hidden" name="action" value="email"><label>Username<input value="<?= e($me['username']) ?>" disabled></label><label>Email<input type="email" name="email" required value="<?= e($me['email']) ?>"></label><div class="full"><button class="btn">Save email</button></div></form></div>
<div class="panel"><h2>Change Password</h2><form method="post" class="fl"><?= csrf_field() ?><input type="hidden" name="action" value="password"><label>Current password<input type="password" name="cur" required></label><label>New password (min 8)<input type="password" name="p1" required minlength="8"></label><label>Confirm new password<input type="password" name="p2" required></label><div class="full"><button class="btn">Change password</button></div></form></div>
<?php require '_bottom.php'; ?>
