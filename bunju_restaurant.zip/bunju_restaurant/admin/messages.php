<?php require '_top.php';
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $id=(int)($_POST['id']??0);
  if(($_POST['action']??'')==='delete'){ $pdo->prepare("DELETE FROM contact_messages WHERE id=?")->execute([$id]); logact('Deleted a message'); flash('Message deleted.'); }
  else $pdo->prepare("UPDATE contact_messages SET is_read=1 WHERE id=?")->execute([$id]);
  header('Location: messages.php'); exit; }
$ms=$pdo->query("SELECT * FROM contact_messages ORDER BY id DESC")->fetchAll(); ?>
<h1>Customer Messages</h1><?php if(!$ms) echo '<div class="panel">No messages yet.</div>'; foreach($ms as $m): ?>
<div class="panel" style="<?= $m['is_read']?'':'border-left:5px solid var(--o)' ?>"><b><?= e($m['name']) ?></b> &middot; <a href="mailto:<?= e($m['email']) ?>"><?= e($m['email']) ?></a><?= $m['phone']?' &middot; '.e($m['phone']):'' ?> <span class="small">(<?= e($m['created_at']) ?>)</span>
<p><?= nl2br(e($m['message'])) ?></p>
<?php if(!$m['is_read']): ?><form method="post" class="inl"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $m['id'] ?>"><button class="btn sm">Mark as read</button></form> <?php endif; ?>
<form method="post" class="inl" data-confirm="Delete this message?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $m['id'] ?>"><button class="btn sm red">Delete</button></form></div><?php endforeach; ?>
<?php require '_bottom.php'; ?>
