<?php require_once __DIR__.'/../config/config.php'; $B=BASE_URL; $err='';
if(empty($_SESSION['reset_admin'])){ header('Location: forgot.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $id=(int)$_SESSION['reset_admin']; $code=trim($_POST['code']??''); $p1=$_POST['p1']??''; $p2=$_POST['p2']??'';
  $st=$pdo->prepare("SELECT * FROM password_resets WHERE admin_id=? AND used=0 AND expires_at>NOW() ORDER BY id DESC LIMIT 1"); $st->execute([$id]); $r=$st->fetch();
  if(strlen($p1)<8) $err='Password must be at least 8 characters.'; elseif($p1!==$p2) $err='Passwords do not match.';
  elseif(!$r || !password_verify($code,$r['code_hash'])) $err='Invalid or expired code.';
  else{ $pdo->prepare("UPDATE admins SET password_hash=? WHERE id=?")->execute([password_hash($p1,PASSWORD_DEFAULT),$id]);
    $pdo->prepare("UPDATE password_resets SET used=1 WHERE admin_id=?")->execute([$id]); unset($_SESSION['reset_admin']); flash('Password changed. Please login.'); header('Location: login.php'); exit; } } ?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reset Password</title><link rel="stylesheet" href="<?= $B ?>/assets/css/style.css"></head><body style="background:var(--g)">
<div class="loginbox"><h1>Reset Password</h1><?php if($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="form"><?= csrf_field() ?><label>6-digit code<input name="code" required maxlength="6" inputmode="numeric"></label><label>New password<input type="password" name="p1" required minlength="8"></label><label>Confirm password<input type="password" name="p2" required></label><button class="btn" style="width:100%">Change password</button></form>
<p class="center"><a href="login.php">Back to login</a></p></div></body></html>
