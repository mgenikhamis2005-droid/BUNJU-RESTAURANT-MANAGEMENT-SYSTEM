<?php require '_top.php';
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $a=$_POST['action']??''; $id=(int)($_POST['id']??0); $name=trim($_POST['name']??''); $d=trim($_POST['description']??'');
  try{
    if($a==='delete'){ $pdo->prepare("DELETE FROM food_categories WHERE id=?")->execute([$id]); logact('Deleted a category'); flash('Category deleted.'); }
    elseif($a==='save'){ if($name===''){ flash('Category name is required.','err'); }
      elseif($id){ $pdo->prepare("UPDATE food_categories SET name=?,description=? WHERE id=?")->execute([$name,$d,$id]); logact("Updated category: $name"); flash('Category updated.'); }
      else{ $pdo->prepare("INSERT INTO food_categories(name,description) VALUES(?,?)")->execute([$name,$d]); logact("Added category: $name"); flash('Category added.'); } }
  }catch(PDOException $ex){ flash($a==='delete'?'Cannot delete: this category still has foods. Move or delete them first.':'That category name already exists.','err'); }
  header('Location: categories.php'); exit; }
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM food_categories WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch(); }
$cats=$pdo->query("SELECT c.*,(SELECT COUNT(*) FROM foods f WHERE f.category_id=c.id) n FROM food_categories c ORDER BY c.id")->fetchAll(); ?>
<h1>Category Management</h1>
<div class="panel"><h2><?= $edit?'Edit Category':'Add Category' ?></h2><form method="post" class="fl"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
<label>Name<input name="name" required maxlength="80" value="<?= e($edit['name']??'') ?>"></label><label>Description<input name="description" maxlength="255" value="<?= e($edit['description']??'') ?>"></label>
<div class="full"><button class="btn"><?= $edit?'Update':'Add' ?></button> <?php if($edit): ?><a class="btn dk" href="categories.php">Cancel</a><?php endif; ?></div></form></div>
<div class="panel"><div class="tw"><table><tr><th>Name</th><th>Description</th><th>Foods</th><th>Actions</th></tr><?php foreach($cats as $c): ?><tr><td><?= e($c['name']) ?></td><td><?= e($c['description']) ?></td><td><?= $c['n'] ?></td>
<td><a class="btn sm" href="categories.php?edit=<?= $c['id'] ?>">Edit</a> <form method="post" class="inl" data-confirm="Delete this category?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="btn sm red">Delete</button></form></td></tr><?php endforeach; ?></table></div></div>
<?php require '_bottom.php'; ?>
