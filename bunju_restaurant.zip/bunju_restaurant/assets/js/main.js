document.addEventListener('DOMContentLoaded',function(){
  var b=document.getElementById('burger'),m=document.getElementById('menu');
  if(b)b.onclick=function(){m.classList.toggle('open');};
  // Slider: change every 5 seconds
  var s=document.querySelectorAll('#slider .slide');
  if(s.length>1){var i=0;setInterval(function(){s[i].classList.remove('active');i=(i+1)%s.length;s[i].classList.add('active');},5000);}
  // Menu details modal
  var fm=document.getElementById('fmodal');
  if(fm){
    document.querySelectorAll('.card.clickable').forEach(function(c){c.onclick=function(){
      var d=c.dataset;document.getElementById('mname').textContent=d.name;document.getElementById('mdesc').textContent=d.desc;
      document.getElementById('mprice').textContent=d.price;document.getElementById('mcat').textContent=d.cat;document.getElementById('mav').textContent=d.av;
      var im=document.getElementById('mimg');im.innerHTML='';if(d.img){var x=document.createElement('img');x.src=d.img;x.alt=d.name;im.appendChild(x);}
      fm.classList.add('show');};});
    document.getElementById('mclose').onclick=function(){fm.classList.remove('show');};
    fm.onclick=function(e){if(e.target===fm)fm.classList.remove('show');};
  }
  // Gallery filter + lightbox
  var gf=document.getElementById('gfilter');
  if(gf){gf.querySelectorAll('a').forEach(function(a){a.onclick=function(e){e.preventDefault();
    gf.querySelectorAll('a').forEach(function(x){x.classList.remove('on');});a.classList.add('on');
    document.querySelectorAll('.ggrid figure').forEach(function(f){f.style.display=(a.dataset.c==='all'||f.dataset.c===a.dataset.c)?'':'none';});};});}
  var lb=document.getElementById('lightbox');
  if(lb){document.querySelectorAll('.ggrid figure').forEach(function(f){f.onclick=function(){
      document.getElementById('limg').src=f.querySelector('img').src;document.getElementById('lcap').textContent=f.querySelector('figcaption').textContent;lb.classList.add('show');};});
    lb.onclick=function(e){if(e.target!==document.getElementById('limg'))lb.classList.remove('show');};}
  // Confirm delete
  document.querySelectorAll('form[data-confirm]').forEach(function(f){f.onsubmit=function(){return confirm(f.dataset.confirm);};});
});
