<?php $page='about'; $title='About Us'; require 'includes/header.php'; ?>
<section class="pagehead"><h1>About Us</h1><p>Good food, made with love</p></section>
<section class="sec wrap"><div class="two"><div><h2>Who We Are</h2><p>BUNJU RESTAURANT is a family-friendly restaurant serving fresh and delicious meals made from quality local ingredients. From grilled seafood to Swahili favourites and fast food, we have something for everyone.</p>
<h3>Our Mission</h3><p>To serve tasty, affordable and hygienic food with excellent customer service.</p>
<h3>Our Vision</h3><p>To be the most loved restaurant in Dar es Salaam, known for quality, hospitality and Tanzanian flavour.</p></div>
<div class="box"><span class="big">&#127859;</span><p>Fresh ingredients. Skilled cooks. Happy customers.</p></div></div></section>
<section class="sec grey"><div class="wrap two"><div><h2>Our Objectives</h2><ul class="ticks"><li>Provide consistently high food quality</li><li>Keep our kitchen and dining area very clean</li><li>Offer fair prices for every customer</li><li>Support local farmers and fishermen</li><li>Train and care for our staff</li></ul></div>
<div><h2>Our Services</h2><ul class="ticks"><li>Dine-in and takeaway</li><li>Event and party catering</li><li>Delivery on request</li><li>Fresh juices, desserts and snacks</li></ul></div></div></section>
<section class="sec wrap"><h2 class="center">Why Choose BUNJU RESTAURANT?</h2><div class="grid4">
<div class="svc lite"><span>&#11088;</span><h3>Quality Food</h3><p>Fresh ingredients cooked to order.</p></div>
<div class="svc lite"><span>&#128522;</span><h3>Friendly Service</h3><p>Our team treats you like family.</p></div>
<div class="svc lite"><span>&#128176;</span><h3>Fair Prices</h3><p>Great meals at prices you can afford.</p></div>
<div class="svc lite"><span>&#129529;</span><h3>Clean Place</h3><p>High hygiene standards every day.</p></div></div></section>
<?php require 'includes/footer.php'; ?>
