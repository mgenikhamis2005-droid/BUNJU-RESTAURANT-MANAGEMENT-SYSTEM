<?php require '_top.php';
$cats=$pdo->query("SELECT * FROM food_categories ORDER BY name")->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $a=$_POST['action']??'';
  if($a==='delete'){ $id=(int)$_POST['id']; $o=$pdo->prepare("SELECT image FROM foods WHERE id=?"); $o->execute([$id]); $old=$o->fetchColumn();
    $pdo->prepare("DELETE FROM foods WHERE id=?")->execute([$id]); delete_file('foods',$old); logact('Deleted a food item'); flash('Food deleted.'); header('Location: foods.php'); exit; }
  if($a==='save'){ $id=(int)($_POST['id']??0); $name=trim($_POST['name']??''); $desc=trim($_POST['description']??''); $price=(float)($_POST['price']??0);
    $op=($_POST['old_price']??'')!==''?(float)$_POST['old_price']:null; $cat=(int)($_POST['category_id']??0);
    $pop=isset($_POST['is_popular'])?1:0; $off=isset($_POST['is_offer'])?1:0; $av=isset($_POST['is_available'])?1:0;
    if($name===''||$price<=0||!$cat){ flash('Name, category and a valid price are required.','err'); header('Location: foods.php'.($id?"?edit=$id":'')); exit; }
    $img=upload_image('image','foods'); if($img===false){ header('Location: foods.php'.($id?"?edit=$id":'')); exit; }
    if($id){ $o=$pdo->prepare("SELECT image FROM foods WHERE id=?"); $o->execute([$id]); $old=$o->fetchColumn();
      $sql="UPDATE foods SET category_id=?,name=?,description=?,price=?,old_price=?,is_popular=?,is_offer=?,is_available=?".($img?",image=?":"")." WHERE id=?";
      $p=[$cat,$name,$desc,$price,$op,$pop,$off,$av]; if($img){ $p[]=$img; delete_file('foods',$old); } $p[]=$id; $pdo->prepare($sql)->execute($p); logact("Updated food: $name"); flash('Food updated.'); }
    else{ $pdo->prepare("INSERT INTO foods(category_id,name,description,price,old_price,image,is_popular,is_offer,is_available) VALUES(?,?,?,?,?,?,?,?,?)")->execute([$cat,$name,$desc,$price,$op,$img,$pop,$off,$av]); logact("Added food: $name"); flash('Food added.'); }
    header('Location: foods.php'); exit; } }
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM foods WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch(); }
$foods=$pdo->query("SELECT f.*,c.name cat FROM foods f JOIN food_categories c ON c.id=f.category_id ORDER BY f.id DESC")->fetchAll(); $v=fn($k,$d='')=>e($edit[$k]??$d); ?>
<h1>Food Management</h1>
<div class="panel"><h2><?= $edit?'Edit Food':'Add New Food' ?></h2>
<form method="post" enctype="multipart/form-data" class="fl"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
<label>Food name<input name="name" required maxlength="120" value="<?= $v('name') ?>"></label>
<label>Category<select name="category_id" required><option value="">Select...</option><?php foreach($cats as $c): ?><option value="<?= $c['id'] ?>" <?= ($edit['category_id']??0)==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></label>
<label>Price (TZS)<input type="number" name="price" min="1" step="1" required value="<?= $edit?(int)$edit['price']:'' ?>"></label>
<label>Old price (for offers, optional)<input type="number" name="old_price" min="0" step="1" value="<?= !empty($edit['old_price'])?(int)$edit['old_price']:'' ?>"></label>
<label class="full">Short description<textarea name="description" rows="2" maxlength="500"><?= $v('description') ?></textarea></label>
<label>Image (JPG/PNG/WEBP, max 3MB)<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label>
<div class="full"><label class="ck"><input type="checkbox" name="is_popular" <?= !empty($edit['is_popular'])?'checked':'' ?>> Popular</label><label class="ck"><input type="checkbox" name="is_offer" <?= !empty($edit['is_offer'])?'checked':'' ?>> Special offer</label><label class="ck"><input type="checkbox" name="is_available" <?= (!$edit||$edit['is_available'])?'checked':'' ?>> Available</label></div>
<div class="full"><button class="btn"><?= $edit?'Update':'Add Food' ?></button> <?php if($edit): ?><a class="btn dk" href="foods.php">Cancel</a><?php endif; ?></div></form></div>
<div class="panel"><h2>All Foods (<?= count($foods) ?>)</h2><div class="tw"><table><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Status</th><th>Actions</th></tr>
<?php foreach($foods as $f): ?><tr><td><?= $f['image']?'<img src="'.$B.'/uploads/foods/'.e($f['image']).'" alt="">':'&#127858;' ?></td><td><?= e($f['name']) ?></td><td><?= e($f['cat']) ?></td><td><?= tzs($f['price']) ?></td>
<td><?= $f['is_available']?'Available':'Unavailable' ?><?= $f['is_popular']?' &middot; Popular':'' ?><?= $f['is_offer']?' &middot; Offer':'' ?></td>
<td><a class="btn sm" href="foods.php?edit=<?= $f['id'] ?>">Edit</a> <form method="post" class="inl" data-confirm="Delete this food?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $f['id'] ?>"><button class="btn sm red">Delete</button></form></td></tr><?php endforeach; ?></table></div></div>
<?php require '_bottom.php'; ?>
