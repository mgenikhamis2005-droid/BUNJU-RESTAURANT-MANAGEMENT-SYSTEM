<?php $page='home'; $title='Home'; require 'includes/header.php';
$slides=$pdo->query("SELECT * FROM slider_images ORDER BY sort_order,id")->fetchAll();
$pop=$pdo->query("SELECT f.*,c.name cat FROM foods f JOIN food_categories c ON c.id=f.category_id WHERE f.is_popular=1 AND f.is_available=1 ORDER BY f.id DESC LIMIT 6")->fetchAll();
$off=$pdo->query("SELECT f.*,c.name cat FROM foods f JOIN food_categories c ON c.id=f.category_id WHERE f.is_offer=1 AND f.is_available=1 ORDER BY f.id DESC LIMIT 4")->fetchAll();
function card($f){ global $B; ?>
<div class="card"><div class="cimg"><?php if($f['image']): ?><img src="<?= $B ?>/uploads/foods/<?= e($f['image']) ?>" alt="<?= e($f['name']) ?>" loading="lazy"><?php else: ?><span class="ph">&#127858;</span><?php endif; ?><?php if($f['is_offer']): ?><b class="tag">OFFER</b><?php endif; ?></div>
<div class="cb"><small><?= e($f['cat']) ?></small><h3><?= e($f['name']) ?></h3><p><?= e($f['description']) ?></p>
<div class="price"><?= tzs($f['price']) ?><?php if($f['old_price']): ?> <s><?= tzs($f['old_price']) ?></s><?php endif; ?></div></div></div>
<?php } ?>
<section class="hero" id="slider">
<?php if($slides): foreach($slides as $i=>$s): ?>
<div class="slide <?= $i===0?'active':'' ?>" style="background-image:linear-gradient(rgba(0,0,0,.45),rgba(0,0,0,.55)),url('<?= $B ?>/uploads/slider/<?= e($s['image']) ?>')"><div class="hc"><h1><?= e($s['title']?:'Welcome to BUNJU RESTAURANT') ?></h1><p><?= e($s['subtitle']?:'Taste the best of Swahili, traditional and modern cuisine') ?></p><a class="btn" href="menu.php">View Menu</a></div></div>
<?php endforeach; else: foreach([['Welcome to BUNJU RESTAURANT','Fresh food, warm hospitality'],['Authentic Swahili Flavours','Pilau, biryani, wali wa nazi and more'],['Fresh Seafood Daily','Grilled fish, prawns and calamari']] as $i=>$s): ?>
<div class="slide def<?= $i ?> <?= $i===0?'active':'' ?>"><div class="hc"><h1><?= e($s[0]) ?></h1><p><?= e($s[1]) ?></p><a class="btn" href="menu.php">View Menu</a></div></div>
<?php endforeach; endif; ?>
</section>
<section class="sec wrap center"><h2>Karibu BUNJU RESTAURANT</h2><p class="lead">We serve freshly prepared seafood, Swahili dishes, traditional meals, fast food, pastries, desserts and drinks in a clean and friendly place for family, friends and events.</p></section>
<section class="sec grey"><div class="wrap"><h2 class="center">Popular Dishes</h2><div class="grid"><?php foreach($pop as $f) card($f); if(!$pop) echo '<p class="center">No popular dishes yet.</p>'; ?></div></div></section>
<?php if($off): ?><section class="sec wrap"><h2 class="center">Special Offers</h2><div class="grid"><?php foreach($off as $f) card($f); ?></div></section><?php endif; ?>
<section class="sec dark"><div class="wrap"><h2 class="center">Our Services</h2><div class="grid4">
<div class="svc"><span>&#127869;</span><h3>Dine-in</h3><p>Comfortable seating for families and groups.</p></div>
<div class="svc"><span>&#128230;</span><h3>Takeaway</h3><p>Order and carry your meal home.</p></div>
<div class="svc"><span>&#127881;</span><h3>Events & Catering</h3><p>Birthdays, meetings and parties.</p></div>
<div class="svc"><span>&#128757;</span><h3>Delivery</h3><p>Call or WhatsApp us to arrange delivery.</p></div></div></div></section>
<section class="sec wrap"><h2 class="center">What Customers Say</h2><div class="grid4">
<blockquote>"The pilau is the best in Dar es Salaam!"<cite>- Amina M.</cite></blockquote>
<blockquote>"Fresh seafood and very friendly staff."<cite>- John K.</cite></blockquote>
<blockquote>"Great prices and fast service. We come every weekend."<cite>- Neema S.</cite></blockquote>
<blockquote>"Perfect place for our family dinner."<cite>- Hassan R.</cite></blockquote></div></section>
<section class="sec grey center"><div class="wrap"><h2>Opening Hours</h2><p class="lead"><?= e(R_HOURS_1) ?><br><?= e(R_HOURS_2) ?></p><a class="btn" href="contact.php">Find Us</a></div></section>
<?php require 'includes/footer.php'; ?>
