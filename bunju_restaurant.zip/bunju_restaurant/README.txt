BUNJU RESTAURANT MANAGEMENT SYSTEM - INSTALLATION (Windows + XAMPP)

1. Install XAMPP (apachefriends.org). Open XAMPP Control Panel and Start "Apache" and "MySQL".
2. Copy the folder "bunju_restaurant" into C:\xampp\htdocs\  (final path: C:\xampp\htdocs\bunju_restaurant\index.php)
3. Open http://localhost/phpmyadmin -> click "Import" -> choose database\bunju_restaurant.sql -> click Go.
   (This creates the database "bunju_restaurant" with all tables and sample menu.)
4. Open the website:  http://localhost/bunju_restaurant/
5. Admin panel:       http://localhost/bunju_restaurant/admin/login.php
   Default login:  username  admin    password  Admin@123
   (created automatically on first visit to the login page) -> CHANGE THE PASSWORD in My Account.
6. Edit restaurant phone, address, email, social links and map location in:  config\config.php
   If your MySQL has a password, set DB_PASS there too.
7. Forgot password: a 6-digit code is emailed. XAMPP cannot send email by default, so while
   DEV_SHOW_CODE is true the code is shown on screen. Set it to false when you host online
   (and use a real mail server / hosting mail).
8. Add food images, gallery pictures and slider images from the admin dashboard.
   The uploads\ folder must be writable (it is by default on Windows).

Folders: assets (css/js/images), config, includes, admin, uploads, database.
