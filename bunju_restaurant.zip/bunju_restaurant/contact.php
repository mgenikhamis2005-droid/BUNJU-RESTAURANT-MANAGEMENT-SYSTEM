<?php $page='contact'; $title='Contact Us'; require 'includes/header.php'; $err=''; $ok=false;
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check();
  $n=trim($_POST['name']??''); $m=trim($_POST['email']??''); $ph=trim($_POST['phone']??''); $msg=trim($_POST['message']??'');
  if($n===''||!filter_var($m,FILTER_VALIDATE_EMAIL)||$msg===''||mb_strlen($msg)>2000||mb_strlen($n)>100) $err='Please enter your name, a valid email and a message.';
  elseif(!empty($_POST['website'])) { $ok=true; }
  else { $pdo->prepare("INSERT INTO contact_messages(name,email,phone,message) VALUES(?,?,?,?)")->execute([$n,$m,mb_substr($ph,0,30),$msg]); $ok=true; } } ?>
<section class="pagehead"><h1>Contact Us</h1><p>We would love to hear from you</p></section>
<section class="sec wrap two">
<div><h2>Get in Touch</h2>
<p><b>Address:</b> <?= e(R_ADDRESS) ?>, <?= e(R_CITY) ?></p><p><b>Phone:</b> <a href="tel:<?= e(preg_replace('/\s+/','',R_PHONE)) ?>"><?= e(R_PHONE) ?></a></p><p><b>Email:</b> <a href="mailto:<?= e(R_EMAIL) ?>"><?= e(R_EMAIL) ?></a></p>
<p><b>Hours:</b><br><?= e(R_HOURS_1) ?><br><?= e(R_HOURS_2) ?></p>
<p class="social"><a class="btn sm" target="_blank" rel="noopener" href="https://wa.me/<?= e(R_WHATSAPP) ?>">WhatsApp</a> <a class="btn sm dk" target="_blank" rel="noopener" href="<?= e(R_INSTAGRAM) ?>">Instagram</a> <a class="btn sm dk" target="_blank" rel="noopener" href="<?= e(R_TIKTOK) ?>">TikTok</a></p></div>
<div><h2>Send a Message</h2>
<?php if($ok): ?><div class="flash ok">Thank you! Your message has been sent.</div><?php endif; if($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="form"><?= csrf_field() ?><input type="text" name="website" class="hp" tabindex="-1" autocomplete="off">
<label>Name<input name="name" required maxlength="100"></label><label>Email<input type="email" name="email" required></label><label>Phone (optional)<input name="phone" maxlength="30"></label>
<label>Message<textarea name="message" rows="5" required maxlength="2000"></textarea></label><button class="btn">Send Message</button></form></div></section>
<section class="wrap sec"><h2 class="center">Find Us</h2>
<iframe class="map" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=<?= urlencode(R_MAP_QUERY) ?>&output=embed"></iframe>
<p class="center"><a class="btn" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=<?= urlencode(R_MAP_QUERY) ?>">Get Directions</a></p></section>
<?php require 'includes/footer.php'; ?>
