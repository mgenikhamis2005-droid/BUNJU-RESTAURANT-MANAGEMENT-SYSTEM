<footer class="foot"><div class="wrap fgrid">
<div><h3>BUNJU RESTAURANT</h3><p>Fresh, tasty and authentic food in the heart of Dar es Salaam.</p></div>
<div><h4>Quick Links</h4><a href="<?= $B ?>/index.php">Home</a><a href="<?= $B ?>/about.php">About Us</a><a href="<?= $B ?>/menu.php">Menu</a><a href="<?= $B ?>/gallery.php">Gallery</a><a href="<?= $B ?>/contact.php">Contact Us</a></div>
<div><h4>Contact</h4><p><?= e(R_ADDRESS) ?><br><?= e(R_CITY) ?></p><p><?= e(R_PHONE) ?><br><?= e(R_EMAIL) ?></p></div>
<div><h4>Follow Us</h4><a target="_blank" rel="noopener" href="<?= e(R_INSTAGRAM) ?>">Instagram</a><a target="_blank" rel="noopener" href="<?= e(R_TIKTOK) ?>">TikTok</a><a target="_blank" rel="noopener" href="https://wa.me/<?= e(R_WHATSAPP) ?>">WhatsApp</a></div>
</div><div class="copy">&copy; <?= date('Y') ?> BUNJU RESTAURANT. All rights reserved.</div></footer>
<script src="<?= $B ?>/assets/js/main.js"></script></body></html>
