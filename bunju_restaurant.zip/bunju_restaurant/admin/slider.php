<?php require '_top.php';
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $a=$_POST['action']??''; $id=(int)($_POST['id']??0);
  if($a==='delete'){ $o=$pdo->prepare("SELECT image FROM slider_images WHERE id=?"); $o->execute([$id]); $old=$o->fetchColumn(); $pdo->prepare("DELETE FROM slider_images WHERE id=?")->execute([$id]); delete_file('slider',$old); logact('Deleted a slider image'); flash('Slide deleted.'); }
  elseif($a==='save'){ $t=trim($_POST['title']??''); $sub=trim($_POST['subtitle']??''); $ord=(int)($_POST['sort_order']??0); $img=upload_image('image','slider');
    if($img===false){ }
    elseif($id){ $o=$pdo->prepare("SELECT image FROM slider_images WHERE id=?"); $o->execute([$id]); $old=$o->fetchColumn();
      if($img){ $pdo->prepare("UPDATE slider_images SET title=?,subtitle=?,sort_order=?,image=? WHERE id=?")->execute([$t,$sub,$ord,$img,$id]); delete_file('slider',$old); } else $pdo->prepare("UPDATE slider_images SET title=?,subtitle=?,sort_order=? WHERE id=?")->execute([$t,$sub,$ord,$id]);
      logact('Updated a slider image'); flash('Slide updated.'); }
    elseif(!$img){ flash('Please choose an image.','err'); }
    else{ $pdo->prepare("INSERT INTO slider_images(title,subtitle,image,sort_order) VALUES(?,?,?,?)")->execute([$t,$sub,$img,$ord]); logact('Added a slider image'); flash('Slide added.'); } }
  header('Location: slider.php'); exit; }
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM slider_images WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch(); }
$rows=$pdo->query("SELECT * FROM slider_images ORDER BY sort_order,id")->fetchAll(); ?>
<h1>Homepage Slider</h1>
<div class="panel"><h2><?= $edit?'Edit / Replace Slide':'Add Slide' ?></h2><form method="post" enctype="multipart/form-data" class="fl"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
<label>Title (optional)<input name="title" maxlength="120" value="<?= e($edit['title']??'') ?>"></label><label>Subtitle (optional)<input name="subtitle" maxlength="200" value="<?= e($edit['subtitle']??'') ?>"></label><label>Order<input type="number" name="sort_order" value="<?= (int)($edit['sort_order']??0) ?>"></label>
<label>Image (wide photo works best)<?= $edit?' - choose a new file to replace':'' ?><input type="file" name="image" accept="image/jpeg,image/png,image/webp" <?= $edit?'':'required' ?>></label>
<div class="full"><button class="btn"><?= $edit?'Update':'Add Slide' ?></button> <?php if($edit): ?><a class="btn dk" href="slider.php">Cancel</a><?php endif; ?></div></form></div>
<div class="panel"><div class="tw"><table><tr><th>Image</th><th>Title</th><th>Order</th><th>Actions</th></tr><?php foreach($rows as $r): ?><tr><td><img src="<?= $B ?>/uploads/slider/<?= e($r['image']) ?>" alt=""></td><td><?= e($r['title']) ?></td><td><?= (int)$r['sort_order'] ?></td>
<td><a class="btn sm" href="slider.php?edit=<?= $r['id'] ?>">Edit / Replace</a> <form method="post" class="inl" data-confirm="Delete this slide?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn sm red">Delete</button></form></td></tr><?php endforeach; ?></table></div><?php if(!$rows) echo '<p>No slides yet: the homepage shows default slides.</p>'; ?></div>
<?php require '_bottom.php'; ?>
