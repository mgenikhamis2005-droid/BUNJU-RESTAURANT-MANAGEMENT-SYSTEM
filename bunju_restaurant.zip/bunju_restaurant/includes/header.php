<?php require_once __DIR__.'/../config/config.php'; $page=$page??'home'; $title=$title??R_NAME; require __DIR__.'/track.php'; $B=BASE_URL;
$nav=['home'=>['Home','index.php'],'about'=>['About Us','about.php'],'menu'=>['Menu','menu.php'],'gallery'=>['Gallery','gallery.php'],'admin'=>['Admin','admin/login.php'],'contact'=>['Contact Us','contact.php']]; ?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> | BUNJU RESTAURANT</title>
<link rel="stylesheet" href="<?= $B ?>/assets/css/style.css"></head><body>
<header class="nav"><div class="wrap navin">
<a class="logo" href="<?= $B ?>/index.php"><span class="logo-i">&#127869;</span> BUNJU <small>RESTAURANT</small></a>
<button class="burger" id="burger" aria-label="Menu">&#9776;</button>
<nav id="menu"><?php foreach($nav as $k=>$v): ?><a href="<?= $B.'/'.$v[1] ?>" class="<?= $page===$k?'on':'' ?>"><?= $v[0] ?></a><?php endforeach; ?></nav>
</div></header>
