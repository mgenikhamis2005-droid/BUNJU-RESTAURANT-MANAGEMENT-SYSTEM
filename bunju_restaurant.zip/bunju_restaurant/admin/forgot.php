<?php require_once __DIR__.'/../config/config.php'; $B=BASE_URL; $msg=''; $dev='';
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check();
  $in=trim($_POST['id']??''); $st=$pdo->prepare("SELECT * FROM admins WHERE username=? OR email=? LIMIT 1"); $st->execute([$in,$in]); $a=$st->fetch();
  if($a){ $code=(string)random_int(100000,999999);
    $pdo->prepare("UPDATE password_resets SET used=1 WHERE admin_id=?")->execute([$a['id']]);
    $pdo->prepare("INSERT INTO password_resets(admin_id,code_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 15 MINUTE))")->execute([$a['id'],password_hash($code,PASSWORD_DEFAULT)]);
    @mail($a['email'],'BUNJU Admin password reset code',"Your reset code is: $code\nIt expires in 15 minutes.","From: ".MAIL_FROM);
    $_SESSION['reset_admin']=$a['id']; if(DEV_SHOW_CODE) $dev=$code; }
  $msg='If the account exists, a 6-digit code has been sent to its email.'; } ?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Forgot Password</title><link rel="stylesheet" href="<?= $B ?>/assets/css/style.css"></head><body style="background:var(--g)">
<div class="loginbox"><h1>Forgot Password</h1><?php if($msg): ?><div class="flash ok"><?= e($msg) ?></div><?php endif; ?>
<?php if($dev): ?><div class="flash err"><b>Local test mode:</b> your code is <b><?= e($dev) ?></b> (XAMPP cannot send email by default).</div><?php endif; ?>
<?php if($msg): ?><p class="center"><a class="btn" href="reset.php">Enter code</a></p><?php else: ?>
<form method="post" class="form"><?= csrf_field() ?><label>Username or email<input name="id" required></label><button class="btn" style="width:100%">Send code</button></form><?php endif; ?>
<p class="center"><a href="login.php">Back to login</a></p></div></body></html>
