<?php
// ===== BUNJU RESTAURANT SETTINGS - edit here =====
define('DB_HOST','localhost');
define('DB_NAME','bunju_restaurant');
define('DB_USER','root');
define('DB_PASS','');                 // XAMPP default is empty
define('BASE_URL','/bunju_restaurant');
define('DEV_SHOW_CODE',true);         // true = show reset code on screen (XAMPP has no mail server). Set false when hosting online.
define('MAIL_FROM','noreply@bunju.co.tz');

define('R_NAME','BUNJU RESTAURANT');
define('R_ADDRESS','Bunju, Bagamoyo Road');
define('R_CITY','Dar es Salaam, Tanzania');
define('R_PHONE','+255 700 000 000');
define('R_EMAIL','info@bunju.co.tz');
define('R_WHATSAPP','255700000000');  // number only, no + sign
define('R_INSTAGRAM','https://www.instagram.com/');
define('R_TIKTOK','https://www.tiktok.com/');
define('R_HOURS_1','Monday - Friday: 08:00 - 22:00');
define('R_HOURS_2','Saturday - Sunday: 09:00 - 23:00');
define('R_MAP_QUERY','Bunju, Dar es Salaam, Tanzania');

session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
session_start();
try {
  $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES=>false]);
} catch (PDOException $ex) {
  die('Database connection failed. Start MySQL in XAMPP and import database/bunju_restaurant.sql in phpMyAdmin.');
}

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function tzs($n){ return 'TZS '.number_format((float)$n); }
function csrf(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(){ return '<input type="hidden" name="csrf" value="'.csrf().'">'; }
function csrf_check(){ if(!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')) die('Invalid request (CSRF check failed). Go back and try again.'); }
function flash($msg=null,$type='ok'){
  if($msg!==null){ $_SESSION['flash']=[$msg,$type]; return; }
  if(!empty($_SESSION['flash'])){ [$m,$t]=$_SESSION['flash']; unset($_SESSION['flash']); return '<div class="flash '.$t.'">'.e($m).'</div>'; }
  return '';
}
function require_admin(){ if(empty($_SESSION['admin_id'])){ header('Location: '.BASE_URL.'/admin/login.php'); exit; } }

// Returns filename on success, null if no file chosen, false if file invalid (flash set)
function upload_image($field,$dir){
  if(empty($_FILES[$field]) || $_FILES[$field]['error']===UPLOAD_ERR_NO_FILE) return null;
  $f=$_FILES[$field];
  if($f['error']!==UPLOAD_ERR_OK){ flash('Upload failed. Try a smaller image.','err'); return false; }
  if($f['size']>3*1024*1024){ flash('Image is too large (max 3MB).','err'); return false; }
  $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;
  if(!$ext || !@getimagesize($f['tmp_name'])){ flash('Only JPG, PNG or WEBP images are allowed.','err'); return false; }
  $name=bin2hex(random_bytes(10)).'.'.$ext;
  if(!move_uploaded_file($f['tmp_name'], __DIR__.'/../uploads/'.$dir.'/'.$name)){ flash('Could not save image. Check uploads folder.','err'); return false; }
  return $name;
}
function delete_file($dir,$name){ if($name && preg_match('/^[a-f0-9]+\.(jpg|png|webp)$/',$name)) @unlink(__DIR__.'/../uploads/'.$dir.'/'.$name); }
