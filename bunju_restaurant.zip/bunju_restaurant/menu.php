<?php $page='menu'; $title='Menu'; require 'includes/header.php';
$q=trim($_GET['q']??''); $cat=(int)($_GET['cat']??0);
$cats=$pdo->query("SELECT * FROM food_categories ORDER BY id")->fetchAll();
$sql="SELECT f.*,c.name cat FROM foods f JOIN food_categories c ON c.id=f.category_id WHERE 1=1"; $p=[];
if($q!==''){ $sql.=" AND f.name LIKE ?"; $p[]='%'.$q.'%'; }
if($cat){ $sql.=" AND f.category_id=?"; $p[]=$cat; }
$sql.=" ORDER BY c.id,f.is_popular DESC,f.name"; $st=$pdo->prepare($sql); $st->execute($p); $foods=$st->fetchAll(); ?>
<section class="pagehead"><h1>Our Menu</h1><p>Meals and drinks made fresh for you</p></section>
<section class="sec wrap">
<form class="filter" method="get"><input type="search" name="q" value="<?= e($q) ?>" placeholder="Search food by name..."><select name="cat"><option value="0">All categories</option><?php foreach($cats as $c): ?><option value="<?= $c['id'] ?>" <?= $cat==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select><button class="btn">Search</button></form>
<div class="chips"><a href="menu.php" class="<?= !$cat?'on':'' ?>">All</a><?php foreach($cats as $c): ?><a href="menu.php?cat=<?= $c['id'] ?>" class="<?= $cat==$c['id']?'on':'' ?>"><?= e($c['name']) ?></a><?php endforeach; ?></div>
<?php if(!$foods): ?><p class="center">No food found.</p><?php endif; ?>
<div class="grid"><?php foreach($foods as $f): $img=$f['image']?$B.'/uploads/foods/'.$f['image']:''; ?>
<div class="card clickable" data-name="<?= e($f['name']) ?>" data-desc="<?= e($f['description']) ?>" data-price="<?= e(tzs($f['price'])) ?>" data-cat="<?= e($f['cat']) ?>" data-img="<?= e($img) ?>" data-av="<?= $f['is_available']?'Available':'Currently unavailable' ?>">
<div class="cimg"><?php if($img): ?><img src="<?= e($img) ?>" alt="<?= e($f['name']) ?>" loading="lazy"><?php else: ?><span class="ph">&#127858;</span><?php endif; ?>
<?php if($f['is_offer']): ?><b class="tag">OFFER</b><?php elseif($f['is_popular']): ?><b class="tag pop">POPULAR</b><?php endif; ?><?php if(!$f['is_available']): ?><b class="tag na">SOLD OUT</b><?php endif; ?></div>
<div class="cb"><small><?= e($f['cat']) ?></small><h3><?= e($f['name']) ?></h3><p><?= e($f['description']) ?></p><div class="price"><?= tzs($f['price']) ?><?php if($f['old_price']): ?> <s><?= tzs($f['old_price']) ?></s><?php endif; ?></div></div></div>
<?php endforeach; ?></div></section>
<div class="modal" id="fmodal"><div class="mbox"><button class="mx" id="mclose">&times;</button><div id="mimg"></div><small id="mcat"></small><h2 id="mname"></h2><p id="mdesc"></p><div class="price" id="mprice"></div><p id="mav"></p></div></div>
<?php require 'includes/footer.php'; ?>
